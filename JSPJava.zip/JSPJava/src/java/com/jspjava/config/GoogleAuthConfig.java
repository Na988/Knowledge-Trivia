package com.jspjava.config;

public class GoogleAuthConfig {
    public static final String CLIENT_ID = "71299449798-pd8m5s5230af6lq9uao3btj39b4vj99u.apps.googleusercontent.com";
    public static final String CLIENT_SECRET = "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";
    public static final String REDIRECT_URI = "http://localhost:8080/JSPJava/oauth2callback";
}                                       